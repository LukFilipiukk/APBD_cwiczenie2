namespace Tutorial3.Models;

public class Salgrade
{
    public int Grade { get; set; }
    public decimal Losal { get; set; }
    public decimal Hisal { get; set; }
}
